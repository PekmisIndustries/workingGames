# workingGames
 github is so scary :(


skrakmi file : 
    0 name
    1 link or torrent bool
    2 link (if 1=0)
    3 magnet (!if 1=1)
    4 zip bool
    5 crack folder bool
    6 crack path (if 4)
    7 crack destination (if 4)
    8 executable path
    9 comments
    10 free